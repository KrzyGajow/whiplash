@echo off

echo ---------------------------------------
echo Started: %date% %time%
echo ---------------------------------------

"C:\Program Files\R\R-4.3.2\bin\Rscript.exe" "D:\Users\Gajowniczek\Kody\Evolution_run.R" > "D:\Users\Gajowniczek\Logi\Logs.txt"

echo Completed: %date% %time%
echo ---------------------------------------

Pause
