##### Libraries ####

sciezka <- "D:/Users/Gajowniczek/"

pakiety <-c("Rcpp_1.0.13","doRNG_1.8.6","foreach_1.5.2","iterators_1.0.14","rngtools_1.5.2","digest_0.6.37","doParallel_1.0.17","doSNOW_1.0.20",
            "snow_0.4-4","GA_3.2.4","cli_3.6.3","crayon_1.5.3","LMR_1.0.0") 

for( i in pakiety ){
  
  suppressWarnings( suppressMessages( install.packages( sprintf( "%sPakiety\\%s.zip", sciezka, i ), repos = NULL, type = "win.binary" ) ) )
                    
}

pakiety <- c("parallel","doSNOW","GA","LMR") 

for( i in pakiety ){
  
  suppressWarnings( suppressMessages( library( sprintf( "%s", i ), character.only = TRUE ) ))
  
}


##### Functions ####
Dif <- function( parent, init, type ){

  out <- if( type[1] == "inter" ){
    
    list( 
    	sum( abs( diff( parent ) ) ), 
    	sum( diff( sign( diff( parent ) ) ) %in% c(-2,2) ),
    	mean( ( parent - init )^2 )
    	)
    
  }else{ list( 0, 0, 0 ) }
  
  return( out )
  
}

Diff <- function( object ){
  
  parent <- as.vector( object )
  out <- list( 0, 0, 0 )
  
  for( i in varGA ){

    split <- splitGA[[ i ]]
    type <- Type[[ i ]]
    init <- Init[[ i ]]
    
    res <- Dif( parent[ split ], init, type )
    
    out[[1]] <- out[[1]] + round( res[[1]], 4 )
    out[[2]] <- out[[2]] + res[[2]]
    out[[3]] <- out[[3]] + round( res[[3]], 4 )

  }

  return( out )
  
}

BinToDec <- function( x, var, init, typ, X, prec, spli, vMin, vMax, gray, coreD, Length, thickLayers ){
  
  lambda <- X
  Comb <- vMax
  for( i in var ){
      
    if( i %in% c("temperature","coreD","Length") ){

      vars <- encode( x[ spli[[ i ]] ], vMin[[ i ]],
                      vMax[[ i ]], prec[[ i ]], gray )
      Comb[[ i ]] <- vars
      
    }else if( length( grep( "thickLayers[[:digit:]]", i ) ) == 1 ){

      vars <- encode( x[ spli[[ i ]] ], vMin[[ i ]], vMax[[ i ]],
                      prec[[ i ]], gray )
      Comb[[ i ]] <- vars

    }else{

      name <- grep( i, names( spli ), value = TRUE )

      vars <- sapply( name, function(j){ encode( x[ spli[[ j ]] ], vMin[[ i ]][ 1 ], vMax[[ i ]][ 1 ],
                                                 prec[[ i ]], gray ) } )
      Comb[[ i ]] <- vars

    }
    
  }
  
  return( Comb )
  
}

varMinMax <- function( var, init, type, varMin, varMax ){
  
  VarMin <- sapply( names(init[ var ]), function( i, init, type, Min ){
    
    if( type[[i]][1] == "value" ){ Min[[i]] }else{ if( type[[i]][1] == "poly" ){
      rep( Min[[i]], as.numeric( type[[i]][2] )+1 ) }else{ rep( Min[[i]], length(init[[i]]) ) } }
    
  }, init = init[ var ], type = type, Min = varMin, simplify = FALSE )
  
  VarMax <- sapply( names(init[ var ]), function( i, init, type, Max ){
    
    if( type[[i]][1] == "value" ){ Max[[i]] }else{ if( type[[i]][1] == "poly" ){
      rep( Max[[i]], as.numeric( type[[i]][2] )+1 ) }else{ rep( Max[[i]], length(init[[i]]) ) } }
    
  }, init = init[ var ], type = type, Max = varMax, simplify = FALSE )
  
  return( list( varMin = VarMin, varMax = VarMax ) )
  
}

Var <- function( var, init, type, prec, repr, varMin, varMax ){
 
  Var <- sapply( names(init[ var ]), function( i, init, type ){
    
    if( type[[i]][1] == "value" ){ init[[i]][1] }else{ if( type[[i]][1] == "poly" ){ attr( init[[i]], "coef" ) }else{ init[[i]] } }
    
  }, init = init[ var ], type = type, simplify = FALSE )

  if( repr == "real-valued" ){
    
    initLen <- cumsum( unlist( lapply( Var, length ) ) )
    initSplit <- vector( "list", length( initLen ) )
    names( initSplit ) <- var
    
  }else{

    initLen <- Var
    for( i in var ){

      temp <- sapply( 1:length(Var[[ i ]]), function(j){
        decode( Var[[ i ]][ j ], varMin[[ i ]][ j ], varMax[[ i ]][ j ], prec[[ i ]], FALSE )
      }, simplify = FALSE )

      Var[[ i ]] <- do.call( "c", temp )
      initLen[[ i ]] <- lapply( temp, length )

    }

    initLen <- cumsum( unlist( initLen ) )
    initSplit <- vector( "list", length( initLen ) )
    names( initSplit ) <- names( initLen )
    
  }

  for( i in 2:(length(initLen)+1) ){
    
    initSplit[[i-1]] <- ( c(0,initLen)[i-1]+1 ):( c(0,initLen)[i] )
    
  }

  assign( "splitGA", initSplit, envir = .GlobalEnv )
  
  return( list( Var = Var, initSplit = initSplit ) )
  
}

CalcComb <- function( repr, fitFun, popSize, pcrossover, pmutation, mutation, crossover, elit,
                      maxiter, miniter, popRand, popType, gray, whip0, seed ){
  
  comb <- expand.grid( 
    repr = repr, fitFun = fitFun, 
    popSize = popSize, pcrossover = pcrossover, pmutation = pmutation,
    mutation = mutation, crossover = crossover, 
    maxiter = maxiter, miniter = miniter,
    elit = elit, popRand = popRand, popType = popType,
    gray = gray, whip0 = whip0, seed = seed,
    stringsAsFactors = FALSE
  )
  
  comb <- comb[ order( comb$seed, comb$popSize, comb$fitFun, comb$mutation, comb$crossover, comb$popType, comb$pcrossover, comb$pmutation,  comb$elit ), ]
  comb <- data.frame( N = 1:nrow(comb), comb ) 
  
  return( comb )
  
}

SensAnalysis <- function( var, X, Target, Params, init, type, Prec, prec, vMin, vMax, comb, stops, nSave, dlugosc, anal, path = getwd() ){
  
  pliki <- list.files( path )
  
  if( !( sprintf( "anal_%s_combs.txt", anal ) %in% pliki ) ){
    
    write.table( comb[,c("N","end")], paste0( path, sprintf( "/anal_%s_combs.txt", anal ) ) , sep = ";", row.names = F )
    
  }
  
  schedule <- read.table( paste0( path, sprintf( "/anal_%s_combs.txt", anal ) ) , sep = ";", header = TRUE )
  poczatek <- which( schedule[ ,"end"] == 0 )[1]  

  if( is.na(poczatek) ){
    
    return( "Koniec" )
    
  }
  
  schedule_slim <- schedule[ ( poczatek ):min( poczatek+dlugosc-1, nrow( comb ) ), , drop = FALSE ]
  comb <- comb[ ( poczatek ):min( poczatek+dlugosc-1, nrow( comb ) ), , drop = FALSE ]
  n <- nrow( comb )

  for( i in 1:length(var) ){

    Prec[[ var[i] ]] <- prec[i]
    
  }
  
  assign( "varGA", var, envir = .GlobalEnv )
  ws <- rep( 1,length(Target) ) / length(Target)
    
  itpar <- unique( c( seq( 0, n, nSave ), n ) )
  resComb <- NULL
  
  print( paste0( "Start: ", Sys.time() ) )

  for( j in 2:length( itpar ) ){

    cl <- parallel::makeCluster( parallel::detectCores() )
    parallel::clusterExport( cl, varlist = c("varMinMax","Var","InitPop","varGA","Type","Init","Prec","ga",
                                             "gareal_Mutation","gareal_Crossover",
                                             "gareal_raMutation","gareal_laCrossover",
                                             "gaLMR","Dif","Diff","BinToDec","encode","decode",
                                             "binary2decimal","decimal2binary"), 
                             envir = parent.frame()  )
    parallel::clusterExport( cl, varlist = c("varMinMax","Var","InitPop","varGA","Type","Init","Prec","ga",
                                             "gareal_Mutation","gareal_Crossover",
                                             "gareal_raMutation","gareal_laCrossover",
                                             "gaLMR","Dif","Diff","BinToDec","encode","decode",
                                             "binary2decimal","decimal2binary"), 
                             envir = globalenv() )
    
    
    registerDoSNOW( cl )

    zakres <- ( itpar[j-1]+1):(itpar[j] )

    start <- Sys.time()
    resComb_temp <- foreach( i = zakres, .errorhandling = "remove" ) %dopar% {

      min_max <- range( schedule_slim[zakres,"N"] )

      #stops <- stops[ stops <= comb[i,"maxiter"] ]
      popul <- matrix( sapply( 1:5, function(x){ ceiling( stops / x ) } ), nrow = length( stops ) )

      monitor <- function( obj ){
       
        st <- sort( ceiling( unique( c( stops, popul[ , comb[i,"popSize"]/10 ] ) ) ) )

	max_fit <- max( obj@fitness ) 
        j <- obj@iter
        if( (j %in% st) | ( max_fit > heaven ) ){ 

          if( comb[i,"repr"] == "real-valued" ){
            
            bes <- obj@population[ which.max( obj@fitness ), , drop = FALSE ]
            
          }else{
            
            bes <- BinToDec( 
                              x = obj@population[ which.max( obj@fitness ),], 
                              var = varGA, init = Init, typ = Type, X = X, prec = Prec, 
                              spli = splitGAbin, 
                              vMin = VarMin_, vMax = VarMax_, 
                              gray = FALSE,
                              coreD = Params$coreDiameter, Length = Params$LengthModifiedRegion, thickLayers = Params$ThicknessCoatingLayers
                            )
            bes <- matrix( unlist( bes ), nrow = 1 )

          }

          uniq_ll <- round( length( unique( obj@population ) ) / prod( dim( obj@population ) ), 4 )
          uniq_col <- round( sum( apply( obj@population, 2, function(x){ length( unique(x) ) / length(x) } ) ), 4 )

          dif <- Diff( bes )
          dif_abs <- dif[[1]]
          dif_sign <- dif[[2]]
          dist_init <- dif[[3]]

          out <- cbind( obj@summary[ j, , drop = FALSE ], 
                        uniq_ll = uniq_ll, uniq_col = uniq_col,
                        dif_abs = dif_abs, dif_sign = dif_sign, dist_init = dist_init
                      )

          print( paste0( "iter_", j ) )
          if( j %in% st ){ 
          
            assign( paste0( "iter_", j ), out, envir = .GlobalEnv ) # .GlobalEnv parent.env( environment() )
            
          }
          if( max_fit > heaven ){ 
          
            assign( "heaven", max_fit, envir = .GlobalEnv )
            assign( paste0( "iter_", 0 ), out, envir = .GlobalEnv ) # .GlobalEnv parent.env( environment() )
            
          }

        }
        
      }

      varMM <- varMinMax( var = var, init = init, type = type, 
                          varMin = structure( as.list( vMin ), names = var ), varMax = structure( as.list( vMax ), names = var ) )

      VarMin <- varMM$varMin
      VarMax <- varMM$varMax

      Var_bin <- Var( var = var, init = init, type = type, prec = Prec, repr = "real-valued", varMin = VarMin, varMax = VarMax )

      Var_ <- Var( var = var, init = init, type = type, prec = Prec, repr = comb[i,"repr"], varMin = VarMin, varMax = VarMax )

      Var <- Var_$Var
      initSplit <- Var_$initSplit

      set.seed( comb[i,"seed"] )
      assign( "SEED", comb[i,"seed"], envir = .GlobalEnv )
      assign( "splitGA", Var_bin$initSplit, envir = .GlobalEnv )
      assign( "splitGAbin", initSplit, envir = .GlobalEnv )
      assign( "VarMin_", VarMin, envir = .GlobalEnv )
      assign( "VarMax_", VarMax, envir = .GlobalEnv )
      assign( "X", X, envir = .GlobalEnv )
      assign( "whip0", comb[i,"whip0"], envir = .GlobalEnv )
      assign( "heaven", -666, envir = .GlobalEnv )

      initPop <- InitPop( sugest = matrix( unlist( Var ), comb[i,"popSize"], length( unlist( Var ) ), byrow = T ), 
                          Vmin = unlist( VarMin ), Vmax = unlist( VarMax ), disturb = comb[i,"popRand"], poptype = comb[i,"popType"] )
      
      layer <- which( !unlist( lapply( init, is.null ) ) )
      layer <- layer[ layer >= 12 ]

      # start <- Sys.time()

      if( comb[i,"repr"] == "real-valued" ){

        GA <- ga( 
                  type = comb[i,"repr"], fitness = gaLMR,
                  mutation = get( comb[i,"mutation"] ), crossover = get( comb[i,"crossover"] ),
                  var = var, init = init, typ = type, X = X, tar = Target, prec = Prec, spli = initSplit, fitF = comb[i,"fitFun"], w = ws,
                  repr = comb[i,"repr"], vMin = unlist( VarMin ), vMax = unlist( VarMax ), gray = comb[i,"gray"],
                  waveMin = Params$waveMin, waveMax = Params$waveMax, waveStep = Params$waveStep,
                  coreD = Params$coreDiameter, Length = Params$LengthModifiedRegion, thickLayers = Params$ThicknessCoatingLayers,
                  Layers = init[ layer ], angleMax = Params$angleMax, integStep = Params$integStep, allResGA = "best",
                  pop = comb[i,"popSize"], iter = comb[i,"maxiter"], par = FALSE, pathDef = NULL, last = FALSE,
                  suggestions = initPop, elitism = ceiling( comb[i,"popSize"] * comb[i,"elit"] ),
                  lower = unlist( VarMin ), upper = unlist( VarMax ),
                  popSize = comb[i,"popSize"], pcrossover = comb[i,"pcrossover"], pmutation = comb[i,"pmutation"],
                  # maxiter = comb[i,"maxiter"], run = comb[i,"miniter"], 500000
                  maxiter = round( 500000 / comb[i,"popSize"] ), run = round( 500000 / comb[i,"popSize"] ), 
                  seed = comb[i,"seed"], 
                  monitor = monitor, parallel = FALSE 
        )
              
      }else{
      
        VarMin <- lapply( VarMin, function(x){ x[1] } )
        VarMax <- lapply( VarMax, function(x){ x[1] } )
        
        GA <- ga( 
          type = comb[i,"repr"], fitness = gaLMR,
          var = var, init = init, typ = type, X = X, tar = Target, prec = Prec, spli = initSplit, fitF = comb[i,"fitFun"], w = ws,
          repr = comb[i,"repr"], vMin = VarMin, vMax = VarMax, gray = comb[i,"gray"],
          waveMin = Params$waveMin, waveMax = Params$waveMax, waveStep = Params$waveStep,
          coreD = Params$coreDiameter, Length = Params$LengthModifiedRegion, thickLayers = Params$ThicknessCoatingLayers,
          Layers = init[ layer ], angleMax = Params$angleMax, integStep = Params$integStep, allResGA = "best",
          pop = comb[i,"popSize"], iter = comb[i,"maxiter"], par = FALSE, pathDef = NULL, last = FALSE,
          nBits = length( unlist( Var ) ), suggestions = NULL, elitism = ceiling( comb[i,"popSize"] * comb[i,"elit"] ),
          popSize = comb[i,"popSize"], pcrossover = comb[i,"pcrossover"], pmutation = comb[i,"pmutation"],
          # maxiter = comb[i,"maxiter"], run = comb[i,"miniter"], 500000
          maxiter = round( 500000 / comb[i,"popSize"] ), run = round( 500000 / comb[i,"popSize"] ), 
          seed = comb[i,"seed"], 
          monitor = monitor, parallel = FALSE 
        )

      }

      # print( difftime( Sys.time(), start, units = "secs" ) )

      # saveRDS( GA, sprintf( "E:/Konferencje/Szymanski/Ewolucja/Gajowniczek/Wyniki/model_%s.rds", i ) )
      # saveRDS( GA, sprintf( "/home/gajowniczekk/Gajowniczek/Wyniki/model_%s.rds", i ) )

      st <- sort( unique( c( stops, popul[ , comb[i,"popSize"]/10 ] ) ) )
      out <- do.call( "rbind", sapply( paste0( "iter_", st ), function(x){ if( exists(x) ){ get( x ) } }, simplify = FALSE ) )
      out <- cbind( comb[ i, , drop = FALSE ], stop = st[1:nrow(out)], out, row.names = NULL ) 
      
      change <- diff( GA@summary[,"max"] )
      changeFit <- ( 1:(comb[i,"maxiter"]-1) )[ change != 0 ]
      changeFit <- changeFit * sign( change )[ change != 0 ]

      out <- list( Res = out, changeFit = changeFit+1 )
      names( out )[2] <- paste0( "Change", comb[i,"N"] )
      
      return( out )
      
    }
    
    min_max <- range( schedule_slim[zakres,"N"] )

    print( paste0( difftime( Sys.time(), start, units = "secs" ), " for iteration: ", min_max[1], "-", min_max[2] ) )
    
    res <- do.call( "rbind", lapply( resComb_temp, function(x){ x[[1]] } ) )
    write.table( res, paste0( path, 
                              sprintf( "/anal_%s_comp_%s_start_%s_end_%s.txt", anal, comb[i,"computer"], min_max[1], min_max[2] ) ), 
                 sep = ";", row.names = FALSE )
    
    changeFit <- lapply( resComb_temp, function(x){ x[[2]] } )
    changeName <- unlist( lapply( resComb_temp, function(x){ names(x[2]) } ) )
    names( changeFit ) <- changeName
    
    saveRDS( changeFit, paste0( path, sprintf( "/anal_%s_comp_%s_start_%s_end_%s.rds", anal, comb[i,"computer"], min_max[1], min_max[2] ) ) )
    
    schedule[ schedule[,"N"] %in% schedule_slim[zakres,"N"], "end" ] <- 1
    write.table( schedule, paste0( path, sprintf( "/anal_%s_combs.txt", anal ) ) , sep = ";", row.names = F )
    
    stopParallel( cl )
    
  }
  
  return( "Sukces" )

}
