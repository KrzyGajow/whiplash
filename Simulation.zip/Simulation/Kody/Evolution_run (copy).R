options( echo = TRUE )
args <- as.numeric( commandArgs( trailingOnly = TRUE ) )

sciezka <- "D:/Users/Gajowniczek/"

source( paste0( sciezka, "Kody/Evolution_functions.R" ) )
load( paste0( sciezka, "Model/Model.RData" ) )
params <- read.table( paste0( sciezka, "Parametry/Parametry.txt" ) , sep = ";", header = FALSE )

ktory_computer <- as.numeric( read.table( paste0( sciezka, "Parametry/Komputer.txt" ), header = FALSE ) ) 
ile_h <- 100000000

ile_LMR <- 130
ile_computer <- 97
ile_proc <- detectCores()

iter <- 10000

set.seed( 123 )
seeds <- sample.int( .Machine$integer.max, 30 )

combs1 <- CalcComb( 
  repr = c( "real-valued" ), fitFun = c( "valley", "MSE" ), 
  popSize = c( 10,20,30,40,50 ), pcrossover = seq( 0.2, 1, 0.2 ), pmutation = seq( 0.2, 1, 0.2 ), 
  mutation = c( "gareal_Mutation", "gareal_raMutation" ), 
  crossover = c( "gareal_Crossover", "gareal_laCrossover" ), elit = c( 0.0, 0.05, 0.1 ),
  maxiter = iter, miniter = iter,
  popRand = 0, popType = c( "null" ), gray = F, 
  seed = seeds
)

combs2 <- CalcComb( 
  repr = c( "real-valued" ), fitFun = c( "valley", "MSE" ), 
  popSize = c( 10,20,30,40,50 ), pcrossover = seq( 0.2, 1, 0.2 ), pmutation = seq( 0.2, 1, 0.2 ), 
  mutation = c( "gareal_Mutation" ), 
  crossover = c( "gareal_Crossover" ), elit = c( 0.0, 0.05, 0.1 ),
  maxiter = iter, miniter = iter,
  popRand = c( 0.2, 0.6, 1 ), popType = c( "center", "whiplash", "independent" ), gray = F, 
  seed = seeds
)

combs3 <- CalcComb( 
  repr = c( "real-valued" ), fitFun = c( "valley", "MSE" ), 
  popSize = c( 10,20,30,40,50 ), pcrossover = seq( 0.2, 1, 0.2 ), pmutation = seq( 0.2, 1, 0.2 ), 
  mutation = c( "gareal_raMutation" ), 
  crossover = c( "gareal_laCrossover" ), elit = c( 0.0, 0.05, 0.1 ),
  maxiter = iter, miniter = iter,
  popRand = c( 0.2, 0.6, 1 ), popType = c( "center", "whiplash", "independent" ), gray = FALSE, 
  seed = seeds
)

combs <- rbind( combs1, combs2, combs3 )
combs <- CalcComb( 
  repr = c( "binary" ), fitFun = c( "valley", "MSE" ), 
  popSize = c( 10,20,30,40,50 ), pcrossover = seq( 0.2, 1, 0.2 ), pmutation = seq( 0.2, 1, 0.2 ), 
  mutation = c( "gareal_raMutation" ), 
  crossover = c( "gareal_laCrossover" ), elit = c( 0.0, 0.05, 0.1 ),
  maxiter = iter, miniter = iter,
  popRand = 0, popType = c( "null" ), gray = FALSE, 
  seed = seeds
)

ile_comb <- nrow( combs )
combs$computer <- rep( 1:ile_computer, length.out = ile_comb )
combs$end <- 0
combs$N <- 1:ile_comb

combs_computer <- combs[ combs$computer == ktory_computer, , drop = FALSE ] 
combs_computer <- combs
jeden_comp <- floor( ( ile_h * 60 * ile_proc ) / ( ile_LMR ) )


print( paste0( "Computer No: ", ktory_computer ) )
print( paste0( "CPU No: ", ile_proc ) )
print( paste0( "Combs All No: ", ile_comb ) )
print( paste0( "Combs Comp No: ", nrow( combs_computer ) ) )
print( head( combs_computer, ile_proc * 2 ) )

SensAnalysis( 
  var = as.character( params[1,] ), 
  X = ResultOpt$Wavelength, Target = ResultOpt$Transmittance, 
  Params = Parameters, init = Init, type = Type,
  Prec = Prec, prec = as.numeric( params[2,] ),
  vMin = as.numeric( params[3,] ), vMax = as.numeric( params[4,] ),
  comb = combs_computer,
  stops = c( 1, 100, 500, 1000, 2500, 5000, 7500, seq( 10000, 100000, 10000 ) ),
  nSave = ile_proc, dlugosc = jeden_comp,
  anal = 1,
  path = paste0( sciezka, "Wyniki" )
)
